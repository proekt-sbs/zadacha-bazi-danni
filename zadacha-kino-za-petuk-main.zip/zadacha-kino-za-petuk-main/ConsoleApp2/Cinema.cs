﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class Cinema
    {
        private string movieName;
        private string movieGenre;
        private bool ageRestriction=false;
        private int capacity;
        private double ticketPrice;
        private int soldTickets;
        private double toatlEarnings;
        public string MovieName { get; set; }
        public string MovieGenre { get; set; }
        public bool AgeRestriction { get;set; }
        public int Capacity { get;set; }
        public double TicketPrice { get;set; }
        public int SoldTickets { get; set; }
        public double TotalEarnings { get; set; }
        public void AddMovie(string name)
        {
            this.MovieName = name;
            if (name.Length == 0)
            {
                throw new ArgumentException("the movie name cant be empty string");
            }
        }
        public void AddGenre(string genre)
        {
            MovieGenre = genre;
            if (genre.Length == 0)
            {
                throw new ArgumentException("the genre cant be empty string");
            }
        }
        public void AddRestriction()
        {
            AgeRestriction = true;
        }
        public void AddCapacity(int capacity1)
        {
            this.Capacity = capacity1;
        }
        public void AddPrice(double price)
        {
            this.TicketPrice = price;
            if (this.TicketPrice < 0)
            {
                throw new ArgumentException("the price cant be negative");
            }
        }
        public void SellTickets(int prodadeno)
        {
            this.SoldTickets = prodadeno;
            if (this.SoldTickets<0)
            {
                throw new ArgumentException("the sold tickets cant be negative");
            }
        }
        public void NegativeCapacity()
        {
            if (this.Capacity < 0)
            {
                throw new ArgumentException("the capacity cant be negative");
            }
        }
        public void CalculateTotalEarnings()
        {
            TotalEarnings= TicketPrice * SoldTickets;
        }
        public void NotEnoughCapacity()
        {
            if(this.Capacity < this.SoldTickets)
            {
                throw new ArgumentException("there is no space for that much people");
            }
        }
    }
}
