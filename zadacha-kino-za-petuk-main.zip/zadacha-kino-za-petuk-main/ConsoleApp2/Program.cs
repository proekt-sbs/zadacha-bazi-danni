﻿namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cinema _cinema = new();
            Console.WriteLine("enter movie name");
            string ime=Console.ReadLine();
            _cinema.AddMovie(ime);
            Console.WriteLine("enter movie genre");
            string zhanr=Console.ReadLine();
            _cinema.AddGenre(zhanr);
            Console.WriteLine("is the movie age restricted: Yes/No");
            string answer = Console.ReadLine();
            if (answer == "Yes")
                _cinema.AddRestriction();
            Console.WriteLine("whats the capacity");
            int capacitet=int.Parse(Console.ReadLine());
            _cinema.AddCapacity(capacitet);
            Console.WriteLine("enter ticket price");
            double cena=double.Parse(Console.ReadLine());
            _cinema.AddPrice(cena);
            Console.WriteLine("enter sold tickets");
            int prodadeno=int.Parse(Console.ReadLine());
            _cinema.SellTickets(prodadeno);
            _cinema.NotEnoughCapacity();
            _cinema.CalculateTotalEarnings();
            Console.WriteLine($"the total earnings from the projection of {_cinema.MovieName} are {_cinema.TotalEarnings}");
        }
    }
}
