using ConsoleApp2;
using System.Security.Cryptography;

namespace TestProject1
{
    public class Tests
    {
        private Cinema _cinema;
        [SetUp]
        public void Setup()
        {
            _cinema = new();
        }

        [Test]
        public void AddMovieNameTest()
        {
            string name = "da ima";
            _cinema.AddMovie(name);
            Assert.AreEqual("da ima", _cinema.MovieName);
        }
        [Test]
        public void EmptyNameTest()
        {
            Assert.Throws<ArgumentException>(() => _cinema.AddMovie(""), "the name cant be empty srting");
        }
        [Test]
        public void AddGenreTest()
        {
            _cinema.MovieGenre = "comedy";
            Assert.AreEqual("comedy", _cinema.MovieGenre);
        }
        [Test]
        public void EmptyGenreTest()
        {
            Assert.Throws<ArgumentException>(() => _cinema.AddGenre(""), "the genre cant be empty string");
        }
        [Test]
        public void RestrictionTest()
        {
            _cinema.AddRestriction();
            Assert.AreEqual(true, _cinema.AgeRestriction);
        }
        [Test]
        public void NotEnoughCapacityTest()
        {
            _cinema.Capacity = 10;
            _cinema.SoldTickets = 11;
            Assert.Throws<ArgumentException>(() => _cinema.NotEnoughCapacity(), "not enough capacity");
        }
        [Test]
        public void AddPriceTest()
        {
            _cinema.AddPrice(15);
            Assert.AreEqual(15, _cinema.TicketPrice);
        }
        [Test]
        public void NegativePriceTest()
        {
            Assert.Throws<ArgumentException>(() => _cinema.AddPrice(-1),"the price cant be negative");
        }
        [Test]
        public void NegativeTicketsSoldTest()
        {
            Assert.Throws<ArgumentException>(() => _cinema.SellTickets(-1), "the sold tickets cant be negative");
        }
        [Test]
        public void NegativeCapacityTest()
        {
            _cinema.Capacity = -1;
            Assert.Throws<ArgumentException>(() => _cinema.NegativeCapacity(), "the capacity cant be negative");
        }
        [Test]
        public void CalculateTotalEarningsTest()
        {
            _cinema.TicketPrice = 10;
            _cinema.SoldTickets = 15;
            _cinema.CalculateTotalEarnings();
            Assert.AreEqual(150, _cinema.TotalEarnings);
        }
    }
}